package com.example.hifimp3

import android.Manifest
import android.content.ContentUris
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.view.Gravity
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer

class MainActivity : ComponentActivity() {
    private lateinit var player: ExoPlayer
    private lateinit var list: ListView
    private lateinit var nowPlaying: TextView
    private lateinit var seek: SeekBar
    private lateinit var playBtn: Button
    private val handler = Handler(Looper.getMainLooper())

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { if (it) loadSongs() }

    private val ticker = object : Runnable {
        override fun run() {
            if (player.duration > 0) {
                seek.max = player.duration.toInt()
                seek.progress = player.currentPosition.toInt()
            }
            handler.postDelayed(this, 500)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Best quality: 32-bit float audio output, no resampling/effects added by the app.
        val factory = DefaultRenderersFactory(this).setEnableAudioFloatOutput(true)
        player = ExoPlayer.Builder(this, factory)
            .setHandleAudioBecomingNoisy(true) // pause when headphones unplugged
            .build()
        player.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                playBtn.text = if (isPlaying) "Pause" else "Play"
            }
            override fun onMediaItemTransition(item: MediaItem?, reason: Int) {
                nowPlaying.text = item?.mediaMetadata?.title ?: "—"
            }
        })

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 64, 24, 24) }
        nowPlaying = TextView(this).apply { text = "Pick a song"; textSize = 18f; gravity = Gravity.CENTER }
        list = ListView(this)
        seek = SeekBar(this)
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) { if (fromUser) player.seekTo(p.toLong()) }
            override fun onStartTrackingTouch(s: SeekBar) {}
            override fun onStopTrackingTouch(s: SeekBar) {}
        })
        val prev = Button(this).apply { text = "Prev"; setOnClickListener { player.seekToPreviousMediaItem() } }
        playBtn = Button(this).apply { text = "Play"; setOnClickListener { if (player.isPlaying) player.pause() else player.play() } }
        val next = Button(this).apply { text = "Next"; setOnClickListener { player.seekToNextMediaItem() } }
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER; addView(prev); addView(playBtn); addView(next) }

        root.addView(nowPlaying)
        root.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(seek)
        root.addView(row)
        setContentView(root)

        val perm = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
                   else Manifest.permission.READ_EXTERNAL_STORAGE
        permLauncher.launch(perm)
        handler.post(ticker)
    }

    private fun loadSongs() {
        val uri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val proj = arrayOf(MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST)
        val items = mutableListOf<MediaItem>()
        val names = mutableListOf<String>()
        contentResolver.query(uri, proj, "${MediaStore.Audio.Media.IS_MUSIC} != 0", null,
            "${MediaStore.Audio.Media.TITLE} ASC")?.use { c ->
            while (c.moveToNext()) {
                val title = c.getString(1) ?: "Unknown"
                val artist = c.getString(2) ?: ""
                names += if (artist.isBlank() || artist == "<unknown>") title else "$title — $artist"
                items += MediaItem.Builder()
                    .setUri(ContentUris.withAppendedId(uri, c.getLong(0)))
                    .setMediaMetadata(MediaMetadata.Builder().setTitle(title).build())
                    .build()
            }
        }
        list.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, names)
        player.setMediaItems(items)
        player.prepare()
        list.setOnItemClickListener { _, _, pos, _ -> player.seekTo(pos, 0); player.play() }
    }

    override fun onDestroy() {
        handler.removeCallbacks(ticker)
        player.release()
        super.onDestroy()
    }
}
