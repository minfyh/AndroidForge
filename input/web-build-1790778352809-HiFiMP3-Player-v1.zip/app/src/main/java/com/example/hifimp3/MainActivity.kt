package com.example.hifimp3

import android.Manifest
import android.content.ContentUris
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture

private data class Song(val id: Long, val title: String, val artist: String, val album: String)

class MainActivity : ComponentActivity() {
    private lateinit var controller: MediaController
    private lateinit var controllerFuture: ListenableFuture<MediaController>
    private lateinit var songList: ListView
    private lateinit var adapter: ArrayAdapter<String>
    private lateinit var search: EditText
    private lateinit var titleView: TextView
    private lateinit var artistView: TextView
    private lateinit var seek: SeekBar
    private lateinit var play: Button
    private lateinit var shuffle: Button
    private lateinit var repeat: Button
    private lateinit var empty: TextView

    private val allSongs = mutableListOf<Song>()
    private val shownSongs = mutableListOf<Song>()
    private val handler = Handler(Looper.getMainLooper())

    private val permissionLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        if (hasAudioPermission()) loadSongs()
    }

    private val progressTicker = object : Runnable {
        override fun run() {
            if (::controller.isInitialized) {
                val duration = controller.duration
                if (duration > 0) {
                    seek.max = duration.coerceAtMost(Int.MAX_VALUE.toLong()).toInt()
                    seek.progress = controller.currentPosition.coerceAtMost(Int.MAX_VALUE.toLong()).toInt()
                }
            }
            handler.postDelayed(this, 500)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()

        controllerFuture = MediaController.Builder(
            this,
            SessionToken(this, android.content.ComponentName(this, MusicService::class.java))
        ).buildAsync()
        controllerFuture.addListener({
            controller = controllerFuture.get()
            controller.addListener(object : Player.Listener {
                override fun onIsPlayingChanged(isPlaying: Boolean) = updateButtons()
                override fun onMediaItemTransition(item: MediaItem?, reason: Int) = updateNowPlaying()
                override fun onShuffleModeEnabledChanged(shuffleModeEnabled: Boolean) = updateButtons()
                override fun onRepeatModeChanged(repeatMode: Int) = updateButtons()
            })
            updateButtons()
            updateNowPlaying()
        }, ContextCompat.getMainExecutor(this))

        requestPermissionsIfNeeded()
        handler.post(progressTicker)
    }

    private fun buildUi() {
        val bg = 0xFF0B0D10.toInt()
        val fg = 0xFFFFFFFF.toInt()
        val secondary = 0xFF9EA4AD.toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 24, 20, 16)
            setBackgroundColor(bg)
        }

        val brand = TextView(this).apply {
            text = "HiFi MP3"
            textSize = 28f
            setTextColor(fg)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            gravity = Gravity.CENTER_VERTICAL
        }
        root.addView(brand, LinearLayout.LayoutParams(-1, 52))

        search = EditText(this).apply {
            hint = "Search music…"
            setHintTextColor(secondary)
            setTextColor(fg)
            singleLine = true
            setPadding(18, 0, 18, 0)
            setBackgroundColor(0xFF171A1F.toInt())
            addTextChangedListener(object : android.text.TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
                override fun onTextChanged(s: CharSequence?, st: Int, before: Int, count: Int) { filterSongs(s?.toString().orEmpty()) }
                override fun afterTextChanged(s: android.text.Editable?) {}
            })
        }
        root.addView(search, LinearLayout.LayoutParams(-1, 52).apply { bottomMargin = 12 })

        empty = TextView(this).apply {
            text = "No music found.\nAllow audio access and place MP3/FLAC files on your phone."
            textSize = 16f
            setTextColor(secondary)
            gravity = Gravity.CENTER
            visibility = View.GONE
        }
        root.addView(empty, LinearLayout.LayoutParams(-1, 0, 1f))

        songList = ListView(this).apply {
            divider = null
            setBackgroundColor(bg)
            setOnItemClickListener { _, _, position, _ -> playSong(shownSongs[position]) }
        }
        adapter = object : ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, mutableListOf()) {
            override fun getView(position: Int, convertView: View?, parent: android.view.ViewGroup): View {
                val v = super.getView(position, convertView, parent) as TextView
                v.setTextColor(fg)
                v.textSize = 16f
                v.setPadding(18, 18, 18, 18)
                return v
            }
        }
        songList.adapter = adapter
        root.addView(songList, LinearLayout.LayoutParams(-1, 0, 1f))

        titleView = TextView(this).apply {
            text = "Nothing playing"
            textSize = 20f
            setTextColor(fg)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            gravity = Gravity.CENTER
        }
        artistView = TextView(this).apply {
            text = ""
            textSize = 14f
            setTextColor(secondary)
            gravity = Gravity.CENTER
        }
        root.addView(titleView, LinearLayout.LayoutParams(-1, 38))
        root.addView(artistView, LinearLayout.LayoutParams(-1, 28))

        seek = SeekBar(this)
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) { if (fromUser && ::controller.isInitialized) controller.seekTo(p.toLong()) }
            override fun onStartTrackingTouch(s: SeekBar) {}
            override fun onStopTrackingTouch(s: SeekBar) {}
        })
        root.addView(seek, LinearLayout.LayoutParams(-1, 42))

        val row = LinearLayout(this).apply { gravity = Gravity.CENTER }
        shuffle = controlButton("Shuffle") { if (::controller.isInitialized) controller.shuffleModeEnabled = !controller.shuffleModeEnabled }
        val prev = controlButton("Prev") { if (::controller.isInitialized) controller.seekToPrevious() }
        play = controlButton("Play") { if (::controller.isInitialized) if (controller.isPlaying) controller.pause() else controller.play() }
        val next = controlButton("Next") { if (::controller.isInitialized) controller.seekToNext() }
        repeat = controlButton("Repeat") { if (::controller.isInitialized) controller.repeatMode = if (controller.repeatMode == Player.REPEAT_MODE_ALL) Player.REPEAT_MODE_OFF else Player.REPEAT_MODE_ALL }
        row.addView(shuffle); row.addView(prev); row.addView(play); row.addView(next); row.addView(repeat)
        root.addView(row, LinearLayout.LayoutParams(-1, 58))

        setContentView(root)
    }

    private fun controlButton(text: String, action: () -> Unit) = Button(this).apply {
        this.text = text
        setOnClickListener { action() }
        setAllCaps(false)
        minWidth = 0
    }

    private fun requestPermissionsIfNeeded() {
        val permissions = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= 33) permissions += Manifest.permission.READ_MEDIA_AUDIO
        else permissions += Manifest.permission.READ_EXTERNAL_STORAGE
        if (Build.VERSION.SDK_INT >= 33) permissions += Manifest.permission.POST_NOTIFICATIONS
        val missing = permissions.filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isEmpty()) loadSongs() else permissionLauncher.launch(missing.toTypedArray())
    }

    private fun hasAudioPermission(): Boolean = ContextCompat.checkSelfPermission(
        this, if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE
    ) == PackageManager.PERMISSION_GRANTED

    private fun loadSongs() {
        allSongs.clear()
        val uri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM
        )
        contentResolver.query(uri, projection, "${MediaStore.Audio.Media.IS_MUSIC} != 0", null, "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC")?.use { c ->
            while (c.moveToNext()) {
                allSongs += Song(
                    c.getLong(0),
                    c.getString(1)?.takeIf { it.isNotBlank() } ?: "Unknown title",
                    c.getString(2)?.takeIf { it.isNotBlank() && it != "<unknown>" } ?: "Unknown artist",
                    c.getString(3)?.takeIf { it.isNotBlank() } ?: "Unknown album"
                )
            }
        }
        filterSongs(search.text.toString())
    }

    private fun filterSongs(query: String) {
        shownSongs.clear()
        val q = query.trim().lowercase()
        shownSongs += allSongs.filter { q.isEmpty() || it.title.lowercase().contains(q) || it.artist.lowercase().contains(q) || it.album.lowercase().contains(q) }
        adapter.clear()
        adapter.addAll(shownSongs.map { "${it.title}\n${it.artist}" })
        adapter.notifyDataSetChanged()
        empty.visibility = if (shownSongs.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun playSong(song: Song) {
        if (!::controller.isInitialized) return
        val uri = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, song.id)
        val item = MediaItem.Builder()
            .setUri(uri)
            .setMediaMetadata(MediaMetadata.Builder().setTitle(song.title).setArtist(song.artist).setAlbumTitle(song.album).build())
            .build()
        controller.setMediaItem(item)
        controller.prepare()
        controller.play()
        hideKeyboard()
    }

    private fun updateNowPlaying() {
        if (!::controller.isInitialized) return
        val item = controller.currentMediaItem ?: return
        titleView.text = item.mediaMetadata.title ?: "Nothing playing"
        artistView.text = item.mediaMetadata.artist ?: ""
    }

    private fun updateButtons() {
        if (!::controller.isInitialized) return
        play.text = if (controller.isPlaying) "Pause" else "Play"
        shuffle.text = if (controller.shuffleModeEnabled) "Shuffle ✓" else "Shuffle"
        repeat.text = if (controller.repeatMode == Player.REPEAT_MODE_ALL) "Repeat ✓" else "Repeat"
    }

    private fun hideKeyboard() {
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(search.windowToken, 0)
    }

    override fun onDestroy() {
        handler.removeCallbacks(progressTicker)
        if (::controllerFuture.isInitialized) MediaController.releaseFuture(controllerFuture)
        super.onDestroy()
    }
}
